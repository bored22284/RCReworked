if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]'Administrator')) {
    Write-Host 'Administrator privileges required. Please run as Administrator.' -ForegroundColor Red
    Read-Host "Press Enter to exit"
    Exit
}

Write-Host "`nSetting SvcHostSplitThresholdInKB to default value (380000)"
reg add "HKLM\SYSTEM\CurrentControlSet\Control" /v "SvcHostSplitThresholdInKB" /t REG_DWORD /d 380000 /f

Write-Host "Done!"
Start-Sleep 2
exit

