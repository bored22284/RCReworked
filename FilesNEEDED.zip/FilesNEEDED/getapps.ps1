Get-AppxPackage | ForEach-Object { $_.Name } > C:\uwpapps.txt
