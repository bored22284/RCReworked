if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]'Administrator')) {
    Write-Host 'Administrator privileges required. Please run as Administrator.' -ForegroundColor Red
    Read-Host "Press Enter to exit"
    Exit
}

$memBytes = (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory
$ramGB = [math]::Round($memBytes / 1GB)

switch ($ramGB) {
    8 { $threshold = 8388608 }
    16 { $threshold = 16777216 }
    32 { $threshold = 33554432 }
    64 { $threshold = 67108864 }
    default { $threshold = 33554432 }
}

Write-Host "`nYour RAM: $ramGB GB"
Write-Host "Suggested SvcHostSplitThresholdInKB: $threshold`n"
Write-Host "[1] Yes, this is my RAM"
Write-Host "[2] No, select manually"

$choice = Read-Host "Enter your choice [1-2]"
if ($choice -eq '2') {
    $manualOptions = @{
        1 = @{ram=8; val=8388608}
        2 = @{ram=16; val=16777216}
        3 = @{ram=32; val=33554432}
        4 = @{ram=64; val=67108864}
    }

    foreach ($k in $manualOptions.Keys) {
        Write-Host "[$k] $($manualOptions[$k].ram) GB"
    }

    $manualChoice = Read-Host "Select your RAM"
    if ($manualOptions.ContainsKey([int]$manualChoice)) {
        $ramGB = $manualOptions[[int]$manualChoice].ram
        $threshold = $manualOptions[[int]$manualChoice].val
    }
}

Write-Host "`nSetting SvcHostSplitThresholdInKB to $threshold for $ramGB GB RAM"
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control" -Name "SvcHostSplitThresholdInKB" -Value $threshold -Type DWord

Write-Host "Done!"
Start-Sleep 2
exit
