@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "defenderremoverver=12.8.4"
pushd "%~dp0"

title Defender Remover v%defenderremoverver%
color 0C
cls

color 0B
echo.
echo  ===========================================================
echo    STEP 1 of 4  -  Removing Windows Security UWP App
echo  ===========================================================
echo.
echo  [ .. ] Running RemoveSecHealthApp.ps1 ...
echo.
timeout /t 1 >nul
Powershell -noprofile -executionpolicy bypass -file "%~dp0\RemoveSecHealthApp.ps1"
echo.
color 0A
echo  [ OK ] Windows Security UWP App removed.
timeout /t 2 >nul

cls
color 0B
echo.
echo  ===========================================================
echo    STEP 2 of 4  -  Unregistering Defender Components
echo  ===========================================================
echo.
echo  [ .. ] Applying registry patches ...
echo.
FOR /R %%f IN (Remove_defender\*.reg)     DO PowerRun.exe regedit.exe /s "%%f"
FOR /R %%f IN (Remove_defender\*.reg)     DO regedit.exe /s "%%f"
FOR /R %%f IN (Remove_SecurityComp\*.reg) DO PowerRun.exe regedit.exe /s "%%f"
echo.
color 0A
echo  [ OK ] Registry entries cleaned.
timeout /t 1 >nul

cls
color 0B
echo.
echo  ===========================================================
echo    STEP 3 of 4  -  Deleting Defender System Files
echo  ===========================================================
echo.
echo  [ .. ] Removing system files ...
echo.
for %%d in (
    "C:\Windows\WinSxS\FileMaps\wow64_windows-defender*.manifest"
    "C:\Windows\WinSxS\FileMaps\x86_windows-defender*.manifest"
    "C:\Windows\WinSxS\FileMaps\amd64_windows-defender*.manifest"
    "C:\Windows\System32\SecurityAndMaintenance_Error.png"
    "C:\Windows\System32\SecurityAndMaintenance.png"
    "C:\Windows\System32\SecurityHealthSystray.exe"
    "C:\Windows\System32\SecurityHealthService.exe"
    "C:\Windows\System32\SecurityHealthHost.exe"
    "C:\Windows\System32\drivers\SgrmAgent.sys"
    "C:\Windows\System32\drivers\WdDevFlt.sys"
    "C:\Windows\System32\drivers\WdBoot.sys"
    "C:\Windows\System32\drivers\WdFilter.sys"
    "C:\Windows\System32\wscsvc.dll"
    "C:\Windows\System32\drivers\WdNisDrv.sys"
    "C:\Windows\System32\wscproxystub.dll"
    "C:\Windows\System32\wscisvif.dll"
    "C:\Windows\System32\SecurityHealthProxyStub.dll"
    "C:\Windows\System32\smartscreen.dll"
    "C:\Windows\SysWOW64\smartscreen.dll"
    "C:\Windows\System32\smartscreen.exe"
    "C:\Windows\SysWOW64\smartscreen.exe"
    "C:\Windows\System32\DWWIN.EXE"
    "C:\Windows\SysWOW64\smartscreenps.dll"
    "C:\Windows\System32\smartscreenps.dll"
    "C:\Windows\System32\SecurityHealthCore.dll"
    "C:\Windows\System32\SecurityHealthSsoUdk.dll"
    "C:\Windows\System32\SecurityHealthUdk.dll"
    "C:\Windows\System32\SecurityHealthAgent.dll"
    "C:\Windows\System32\wscapi.dll"
    "C:\Windows\System32\wscadminui.exe"
    "C:\Windows\SysWOW64\GameBarPresenceWriter.exe"
    "C:\Windows\System32\GameBarPresenceWriter.exe"
    "C:\Windows\SysWOW64\DeviceCensus.exe"
    "C:\Windows\SysWOW64\CompatTelRunner.exe"
    "C:\Windows\system32\drivers\msseccore.sys"
    "C:\Windows\system32\drivers\MsSecFltWfp.sys"
    "C:\Windows\system32\drivers\MsSecFlt.sys"
) DO (
    echo  [ .. ] Deleting %%~d
    PowerRun cmd.exe /c del /f %%d
)
echo.
color 0A
echo  [ OK ] System files removed.
timeout /t 1 >nul

cls
color 0B
echo.
echo  ===========================================================
echo    STEP 4 of 4  -  Removing Defender Directories
echo  ===========================================================
echo.
echo  [ .. ] Deleting Defender folders ...
echo.
for %%d in (
    "C:\Windows\WinSxS\amd64_security-octagon*"
    "C:\Windows\WinSxS\x86_windows-defender*"
    "C:\Windows\WinSxS\wow64_windows-defender*"
    "C:\Windows\WinSxS\amd64_windows-defender*"
    "C:\Windows\SystemApps\Microsoft.Windows.AppRep.ChxApp_cw5n1h2txyewy"
    "C:\ProgramData\Microsoft\Windows Defender"
    "C:\ProgramData\Microsoft\Windows Defender Advanced Threat Protection"
    "C:\Program Files (x86)\Windows Defender Advanced Threat Protection"
    "C:\Program Files\Windows Defender Advanced Threat Protection"
    "C:\ProgramData\Microsoft\Windows Security Health"
    "C:\ProgramData\Microsoft\Storage Health"
    "C:\WINDOWS\System32\drivers\wd"
    "C:\Program Files (x86)\Windows Defender"
    "C:\Program Files\Windows Defender"
    "C:\Windows\System32\SecurityHealth"
    "C:\Windows\System32\WebThreatDefSvc"
    "C:\Windows\System32\Sgrm"
    "C:\Windows\Containers\WindowsDefenderApplicationGuard.wim"
    "C:\Windows\SysWOW64\WindowsPowerShell\v1.0\Modules\DefenderPerformance"
    "C:\Windows\System32\WindowsPowerShell\v1.0\Modules\DefenderPerformance"
    "C:\Windows\System32\WindowsPowerShell\v1.0\Modules\Defender"
    "C:\Windows\System32\Tasks_Migrated\Microsoft\Windows\Windows Defender"
    "C:\Windows\System32\Tasks\Microsoft\Windows\Windows Defender"
    "C:\Windows\SysWOW64\WindowsPowerShell\v1.0\Modules\Defender"
    "C:\Windows\System32\HealthAttestationClient"
    "C:\Windows\GameBarPresenceWriter"
    "C:\Windows\bcastdvr"
    "C:\Windows\Containers\serviced\WindowsDefenderApplicationGuard.wim"
) DO (
    echo  [ .. ] Removing %%~d
    PowerRun cmd.exe /c rmdir "%%~d" /s /q
)
echo.
color 0A
echo  [ OK ] Defender directories removed.
timeout /t 1 >nul

cls
color 0A
echo.
echo  ===========================================================
echo.
echo    Windows Defender Has Been Completely Removed.
echo    Please restart your PC to apply all changes.
echo.
echo  ===========================================================
echo.
timeout /t 1 >nul
exit