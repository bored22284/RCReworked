﻿function Ensure-Admin {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) {
        $scriptPath = $MyInvocation.MyCommand.Definition
        if (-not (Test-Path $scriptPath)) { 
            [System.Windows.Forms.MessageBox]::Show("Cannot determine script path.`nPlease run the script from a saved .ps1 file.","Error","OK","Error")
            exit
        }
        Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`"" -Verb RunAs
        exit
    }
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.Win32

function Show-TimedMessage {
    param (
        [string]$processName,
        [string]$oldPriority,
        [string]$newPriority,
        [int]$durationSeconds = 2
    )
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Priority Changed"
    $form.StartPosition = "CenterScreen"
    $form.Size = New-Object System.Drawing.Size(350,150)
    $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.TopMost = $true
    $form.BackColor = [System.Drawing.Color]::Black

    $label = New-Object System.Windows.Forms.Label
    $label.Text = "$($processName.ToUpper())`nPriority changed from $oldPriority > $newPriority"
    $label.Dock = "Fill"
    $label.TextAlign = "MiddleCenter"
    $label.Padding = New-Object System.Windows.Forms.Padding(10)
    $label.ForeColor = [System.Drawing.Color]::Red
    $label.BackColor = [System.Drawing.Color]::Black
    $form.Controls.Add($label)

    $form.Show()
    Start-Sleep -Seconds $durationSeconds
    $form.Close()
}

function Show-AutoPriorityPopup {
    param ([array]$changes)
    if ($changes.Count -eq 0) { return }
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Auto Priorities Changed"
    $form.StartPosition = "CenterScreen"
    $form.Size = New-Object System.Drawing.Size(400,400)
    $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.TopMost = $true
    $form.BackColor = [System.Drawing.Color]::Black

    $textBox = New-Object System.Windows.Forms.TextBox
    $textBox.Multiline = $true
    $textBox.ReadOnly = $true
    $textBox.Dock = "Fill"
    $textBox.ScrollBars = "Vertical"
    $textBox.BackColor = [System.Drawing.Color]::Black
    $textBox.ForeColor = [System.Drawing.Color]::Lime

    foreach ($c in $changes) {
        $textBox.AppendText("$($c.Name) > Instances: $($c.Count)`r`nChanged priority from $($c.Old) → $($c.New)`r`n`r`n")
    }

    $form.Controls.Add($textBox)
    $form.ShowDialog()
}

function Get-CsrssPriorityFromRegistry {
    $keyPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\csrss.exe\PerfOptions"
    if (Test-Path $keyPath) {
        $cpuPriority = (Get-ItemProperty -Path $keyPath -Name "CpuPriorityClass" -ErrorAction SilentlyContinue).CpuPriorityClass
        switch ($cpuPriority) {
            1 { return "Idle" }
            2 { return "Normal" }
            3 { return "High" }
            4 { return "RealTime" }
            5 { return "BelowNormal" }
            6 { return "AboveNormal" }
            default { return "Unknown" }
        }
    }
    return "Unknown"
}

function Set-CsrssPriorityInRegistry($priority) {
    $keyPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\csrss.exe\PerfOptions"
    if (-not (Test-Path $keyPath)) { New-Item -Path $keyPath -Force | Out-Null }
    $cpuPriorityValue = switch ($priority.ToLower()) {
        "idle"         { 1 }
        "normal"       { 2 }
        "high"         { 3 }
        "realtime"     { 4 }
        "belownormal"  { 5 }
        "abovenormal"  { 6 }
        default        { 2 }
    }
    Set-ItemProperty -Path $keyPath -Name "CpuPriorityClass" -Value $cpuPriorityValue -Type DWord
    Set-ItemProperty -Path $keyPath -Name "IoPriority" -Value 3 -Type DWord
    $reg = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\csrss.exe\PerfOptions", $true)
    $reg.Flush()
    $reg.Close()
}

Ensure-Admin

$form = New-Object System.Windows.Forms.Form
$form.Text = "Priority Tool"
$form.Size = New-Object System.Drawing.Size(840,580)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::FromArgb(28,28,30)
$form.ForeColor = [System.Drawing.Color]::White
$form.Font = New-Object System.Drawing.Font("Segoe UI",10)

$searchText = ""

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = "Priority Tool"
$titleLabel.Font = New-Object System.Drawing.Font("Segoe UI",20,[System.Drawing.FontStyle]::Bold)
$titleLabel.Location = New-Object System.Drawing.Point(15,10)
$titleLabel.AutoSize = $true
$form.Controls.Add($titleLabel)

$searchBox = New-Object System.Windows.Forms.TextBox
$searchBox.Size = New-Object System.Drawing.Size(280,28)
$searchBox.Location = New-Object System.Drawing.Point(540,20)
$form.Controls.Add($searchBox)

$processGrid = New-Object System.Windows.Forms.DataGridView
$processGrid.Size = New-Object System.Drawing.Size(765,380)
$processGrid.Location = New-Object System.Drawing.Point(15,60)
$processGrid.SelectionMode = 'FullRowSelect'
$processGrid.MultiSelect = $false
$processGrid.AllowUserToAddRows = $false
$processGrid.RowHeadersVisible = $false
$processGrid.BackgroundColor = [System.Drawing.Color]::FromArgb(37,37,38)
$processGrid.GridColor = [System.Drawing.Color]::FromArgb(60,60,60)
$processGrid.EnableHeadersVisualStyles = $false
$processGrid.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(45,45,48)
$processGrid.ColumnHeadersDefaultCellStyle.ForeColor = [System.Drawing.Color]::White
$processGrid.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(37,37,38)
$processGrid.DefaultCellStyle.ForeColor = [System.Drawing.Color]::White
$processGrid.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(0,122,204)
$processGrid.DefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White
$form.Controls.Add($processGrid)

$processGrid.Columns.Add("Name","Process Name") | Out-Null
$processGrid.Columns.Add("Running","Running") | Out-Null
$processGrid.Columns.Add("Priority","Priority") | Out-Null
$processGrid.Columns[0].Width = 460
$processGrid.Columns[1].Width = 80
$processGrid.Columns[2].Width = 150

$priorityCombo = New-Object System.Windows.Forms.ComboBox
$priorityCombo.Location = New-Object System.Drawing.Point(15,510)
$priorityCombo.Size = New-Object System.Drawing.Size(160,30)
$priorityCombo.Items.AddRange(@("RealTime","High","AboveNormal","Normal","BelowNormal","Idle"))
$priorityCombo.SelectedIndex = 3
$form.Controls.Add($priorityCombo)

$buttonWidth = 180
$buttonHeight = 30

$applyButton = New-Object System.Windows.Forms.Button
$applyButton.Text = "Apply Priority"
$applyButton.Size = New-Object System.Drawing.Size($buttonWidth,$buttonHeight)
$applyButton.Location = New-Object System.Drawing.Point(190,510)
$form.Controls.Add($applyButton)

$recommendedButton = New-Object System.Windows.Forms.Button
$recommendedButton.Text = "Auto Priorities"
$recommendedButton.Size = New-Object System.Drawing.Size($buttonWidth,$buttonHeight)
$recommendedButton.Location = New-Object System.Drawing.Point(380,510)
$form.Controls.Add($recommendedButton)

$refreshButton = New-Object System.Windows.Forms.Button
$refreshButton.Text = "Refresh"
$refreshButton.Size = New-Object System.Drawing.Size($buttonWidth,$buttonHeight)
$refreshButton.Location = New-Object System.Drawing.Point(570,510)
$form.Controls.Add($refreshButton)

function Refresh-ProcessList {
    $processGrid.Rows.Clear()
    $groups = Get-Process | Group-Object ProcessName | Sort-Object Name
    foreach ($g in $groups) {
        if ($searchText -ne "" -and $g.Name -notlike "*$searchText*") { continue }
        $priority = ""
        if ($g.Name.ToLower() -eq "csrss") {
            $priority = Get-CsrssPriorityFromRegistry
        } else {
            try { $priority = ($g.Group | Select-Object -First 1).PriorityClass } catch { $priority = "Access Denied" }
        }
        $processGrid.Rows.Add($g.Name,$g.Count,$priority) | Out-Null
    }
    if ($processGrid.Rows.Count -gt 0) { $processGrid.Rows[0].Selected = $true }
}

$applyButton.Add_Click({
    if ($processGrid.SelectedRows.Count -eq 0) { return }
    $name = $processGrid.SelectedRows[0].Cells[0].Value
    $oldPriority = $processGrid.SelectedRows[0].Cells[2].Value
    $newPriority = $priorityCombo.SelectedItem
    $success = $false
    if ($name.ToLower() -eq "csrss") {
        try {
            if ($newPriority -eq "Remove Priority") {
                $keyPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\csrss.exe\PerfOptions"
                if (Test-Path $keyPath) { Remove-Item -Path $keyPath -Recurse -Force }
                $success = $true
            } else {
                Set-CsrssPriorityInRegistry $newPriority
                $success = $true
            }
        } catch {}
    } else {
        Get-Process -Name $name -ErrorAction SilentlyContinue | ForEach-Object { try { $_.PriorityClass = $newPriority; $success = $true } catch {} }
    }
    Refresh-ProcessList
    if ($success -and $newPriority -ne "Remove Priority") { Show-TimedMessage $name $oldPriority $newPriority 2 }
})

$recommendedButton.Add_Click({
    Get-Process -Name "MicrosoftEdgeUpdate" -ErrorAction SilentlyContinue | Stop-Process -Force
    $map = @{
        "discord" = "BelowNormal"
        "firefox" = "BelowNormal"
        "brave" = "BelowNormal"
        "spotify" = "BelowNormal"
        "notepad" = "BelowNormal"
        "bitwarden" = "BelowNormal"
        "p-stream" = "BelowNormal"
        "womicclient" = "BelowNormal"
        "gamemanagerservice3" = "BelowNormal"
        "razer_elevation_service" = "BelowNormal"
        "razerappengine" = "BelowNormal"
        "rzengnemon" = "BelowNormal"
        "thorium" = "BelowNormal"
        "xmousebuttoncontrol" = "BelowNormal"
        "editor" = "BelowNormal"
        "deviceselector" = "BelowNormal"
        "hrc" = "BelowNormal"
        "chrome" = "BelowNormal"
        "edge" = "BelowNormal"
        "opera" = "BelowNormal"
        "vivaldi" = "BelowNormal"
        "safari" = "BelowNormal"
        "epicwebhelper" = "Idle"
        "steamwebhelper" = "Idle"
        "steam" = "BelowNormal"
        "robloxcrashhandler" = "Idle"
        "robloxplayerbeta" = "High"
        "lightshot" = "Idle"
        "EpicGamesLauncher" = "BelowNormal"
        "teams" = "Idle"
        "zoom" = "Idle"
        "slack" = "Idle"
        "skype" = "Idle"
        "msteams" = "Idle"
    }
    $allProcesses = Get-Process
    $changes = @()
    foreach ($pName in $allProcesses | Select-Object -ExpandProperty ProcessName -Unique) {
        $nameLower = $pName.ToLower()
        if ($map.ContainsKey($nameLower)) {
            try {
                $instances = ($allProcesses | Where-Object ProcessName -eq $pName).Count
                $oldPriority = ($allProcesses | Where-Object ProcessName -eq $pName | Select-Object -First 1).PriorityClass.ToString()
                $newPriority = $map[$nameLower]
                ($allProcesses | Where-Object ProcessName -eq $pName).ForEach({ $_.PriorityClass = $newPriority })
                $changes += [PSCustomObject]@{
                    Name  = $pName
                    Count = $instances
                    Old   = $oldPriority
                    New   = $newPriority
                }
            } catch {}
        }
    }
    Show-AutoPriorityPopup -changes $changes
    Refresh-ProcessList
})

$refreshButton.Add_Click({ Refresh-ProcessList })
$searchBox.Add_TextChanged({ $searchText = $searchBox.Text; Refresh-ProcessList })

$processGrid.Add_SelectionChanged({
    if ($processGrid.SelectedRows.Count -eq 0) { return }
    $name = $processGrid.SelectedRows[0].Cells[0].Value
    $priorityCombo.Items.Clear()
    $priorityCombo.Items.AddRange(@("RealTime","High","AboveNormal","Normal","BelowNormal","Idle"))
    if ($name.ToLower() -eq "csrss") {
        $priorityCombo.Items.Add("Remove Priority")
        $priorityCombo.SelectedItem = Get-CsrssPriorityFromRegistry
    } else {
        try { $priorityCombo.SelectedItem = (Get-Process -Name $name | Select-Object -First 1).PriorityClass.ToString() } catch { $priorityCombo.SelectedItem = "Normal" }
    }
})

Refresh-ProcessList
$form.Add_Shown({$form.Activate()})
[void]$form.ShowDialog()
