Configuration PowerSettingsDSC {
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    function Get-RegistryList {
        param (
            [string[]]$Paths,
            [string]$PropertyMatch
        )
        return Get-ChildItem -Path $Paths -ErrorAction SilentlyContinue -Recurse |
            Where-Object { $_.Property -contains $PropertyMatch } |
            Select-Object -ExpandProperty Name |
            ForEach-Object { $_ -replace "HKEY_LOCAL_MACHINE", "HKLM:" } |
            Select-Object -Unique
    }

    $PropertiesAndValues = @{
        "AllowIdleIrpInD3"                           = @{ ValueName = "AllowIdleIrpInD3"                           ; ValueType = "DWord"  ; ValueData = "0" }
        "AudioAlwaysOn"                              = @{ ValueName = "AudioAlwaysOn"                              ; ValueType = "DWord"  ; ValueData = "1" }
        "BusyPauseTime"                              = @{ ValueName = "BusyPauseTime"                              ; ValueType = "DWord"  ; ValueData = "0" }
        "D3ColdSupported"                            = @{ ValueName = "D3ColdSupported"                            ; ValueType = "DWord"  ; ValueData = "0" }
        "DeviceD0DelayTime"                          = @{ ValueName = "DeviceD0DelayTime"                          ; ValueType = "DWord"  ; ValueData = "0" }
        "DeviceSelectiveSuspended"                   = @{ ValueName = "DeviceSelectiveSuspended"                   ; ValueType = "DWord"  ; ValueData = "0" }
        "DisableD3Cold"                              = @{ ValueName = "DisableD3Cold"                              ; ValueType = "DWord"  ; ValueData = "1" }
        "DisableIdlePowerManagement"                 = @{ ValueName = "DisableIdlePowerManagement"                 ; ValueType = "DWord"  ; ValueData = "1" }
        "DisableLPM"                                 = @{ ValueName = "DisableLPM"                                 ; ValueType = "DWord"  ; ValueData = "1" }
        "DisableRuntimePowerManagement"              = @{ ValueName = "DisableRuntimePowerManagement"              ; ValueType = "DWord"  ; ValueData = "1" }
        "DisableSelectiveSuspend"                    = @{ ValueName = "DisableSelectiveSuspend"                    ; ValueType = "DWord"  ; ValueData = "1" }
        "DmaRemappingCompatible"                     = @{ ValueName = "DmaRemappingCompatible"                     ; ValueType = "DWord"  ; ValueData = "0" }
        "EnableCodecPowerSaving"                     = @{ ValueName = "EnableCodecPowerSaving"                     ; ValueType = "Binary" ; ValueData = "00000000" }
        "EnableD3Cold"                               = @{ ValueName = "EnableD3Cold"                               ; ValueType = "DWord"  ; ValueData = "0" }
        "EnableDiagnosticMode"                       = @{ ValueName = "EnableDiagnosticMode"                       ; ValueType = "DWord"  ; ValueData = "0" }
        "EnableIdlePowerManagement"                  = @{ ValueName = "EnableIdlePowerManagement"                  ; ValueType = "DWord"  ; ValueData = "0" }
        "EnableSelectiveSuspend"                     = @{ ValueName = "EnableSelectiveSuspend"                     ; ValueType = "DWord"  ; ValueData = "0" }
        "EnhancedPowerManagementEnabled"             = @{ ValueName = "EnhancedPowerManagementEnabled"             ; ValueType = "DWord"  ; ValueData = "0" }
        "EnumerationRetryCount"                      = @{ ValueName = "EnumerationRetryCount"                      ; ValueType = "DWord"  ; ValueData = "0" }
        "ExtPropDescSemaphore"                       = @{ ValueName = "ExtPropDescSemaphore"                       ; ValueType = "DWord"  ; ValueData = "0" }
        "fid_D1Latency"                              = @{ ValueName = "fid_D1Latency"                              ; ValueType = "DWord"  ; ValueData = "0" }
        "fid_D2Latency"                              = @{ ValueName = "fid_D2Latency"                              ; ValueType = "DWord"  ; ValueData = "0" }
        "fid_D3Latency"                              = @{ ValueName = "fid_D3Latency"                              ; ValueType = "DWord"  ; ValueData = "0" }
        "ForceFullSpeed"                             = @{ ValueName = "ForceFullSpeed"                             ; ValueType = "DWord"  ; ValueData = "1" }
        "IdleEnable"                                 = @{ ValueName = "IdleEnable"                                 ; ValueType = "DWord"  ; ValueData = "0" }
        "IdleInWorkingState"                         = @{ ValueName = "IdleInWorkingState"                         ; ValueType = "DWord"  ; ValueData = "0" }
        "InterruptThreshold"                         = @{ ValueName = "InterruptThreshold"                         ; ValueType = "DWord"  ; ValueData = "1" }
        "IoLatencyCap"                               = @{ ValueName = "IoLatencyCap"                               ; ValueType = "DWord"  ; ValueData = "0" }
        "IoTimeoutValue"                             = @{ ValueName = "IoTimeoutValue"                             ; ValueType = "DWord"  ; ValueData = "0" }
        "IsochronousTransferMode"                    = @{ ValueName = "IsochronousTransferMode"                    ; ValueType = "DWord"  ; ValueData = "1" }
        "Latency"                                    = @{ ValueName = "Latency"                                    ; ValueType = "DWord"  ; ValueData = "1" }
        "LowLatencyMode"                             = @{ ValueName = "LowLatencyMode"                             ; ValueType = "DWord"  ; ValueData = "1" }
        "MSISupported"                               = @{ ValueName = "MSISupported"                               ; ValueType = "DWord"  ; ValueData = "1" }
        "PreventDebounceTimeForSuperSpeedDevices"    = @{ ValueName = "PreventDebounceTimeForSuperSpeedDevices"    ; ValueType = "DWord"  ; ValueData = "1" }
        "RemappingFlags"                             = @{ ValueName = "RemappingFlags"                             ; ValueType = "DWord"  ; ValueData = "0" }
        "RemappingSupported"                         = @{ ValueName = "RemappingSupported"                         ; ValueType = "DWord"  ; ValueData = "0" }
        "SelectiveSuspendEnabled"                    = @{ ValueName = "SelectiveSuspendEnabled"                    ; ValueType = "DWord"  ; ValueData = "0" }
        "SelectiveSuspendOn"                         = @{ ValueName = "SelectiveSuspendOn"                         ; ValueType = "DWord"  ; ValueData = "0" }
        "SriovSupported"                             = @{ ValueName = "SriovSupported"                             ; ValueType = "DWord"  ; ValueData = "0" }
        "ThrottleMask"                               = @{ ValueName = "ThrottleMask"                               ; ValueType = "DWord"  ; ValueData = "-1" }
        "Usb20HardwareLpmOverride"                   = @{ ValueName = "Usb20HardwareLpmOverride"                   ; ValueType = "DWord"  ; ValueData = "0" }
        "Usb30HardwareLpmOverride"                   = @{ ValueName = "Usb30HardwareLpmOverride"                   ; ValueType = "DWord"  ; ValueData = "0" }
        "USBDSpinWait"                               = @{ ValueName = "USBDSpinWait"                               ; ValueType = "DWord"  ; ValueData = "-1" }
        "WaitWakeEnabled"                            = @{ ValueName = "WaitWakeEnabled"                            ; ValueType = "DWord"  ; ValueData = "0" }
        "WdfDefaultIdleInWorkingState"               = @{ ValueName = "WdfDefaultIdleInWorkingState"               ; ValueType = "DWord"  ; ValueData = "0" }
        "WdfDirectedPowerTransitionChildrenOptional" = @{ ValueName = "WdfDirectedPowerTransitionChildrenOptional" ; ValueType = "DWord"  ; ValueData = "0" }
        "WdfDirectedPowerTransitionEnable"           = @{ ValueName = "WdfDirectedPowerTransitionEnable"           ; ValueType = "DWord"  ; ValueData = "0" }
        "EnhancedPowerManagementUseMonitor"          = @{ ValueName = "EnhancedPowerManagementUseMonitor"          ; ValueType = "DWord"  ; ValueData = "0" }
        "IdleTimeoutPeriodInMilliSec"                = @{ ValueName = "IdleTimeoutPeriodInMilliSec"                ; ValueType = "DWord"  ; ValueData = "0" }
        "SelectiveSuspendTimeout"                    = @{ ValueName = "SelectiveSuspendTimeout"                    ; ValueType = "DWord"  ; ValueData = "0" }
        "SleepstudyState"                            = @{ ValueName = "SleepstudyState"                            ; ValueType = "DWord"  ; ValueData = "0" }
        "SuppressInputInCS"                          = @{ ValueName = "SuppressInputInCS"                          ; ValueType = "DWord"  ; ValueData = "0" }
        "SystemInputSuppressionEnabled"              = @{ ValueName = "SystemInputSuppressionEnabled"              ; ValueType = "DWord"  ; ValueData = "0" }
        "WdfUseWdfTimerForPofx"                      = @{ ValueName = "WdfUseWdfTimerForPofx"                      ; ValueType = "DWord"  ; ValueData = "0" }
    }

    $Paths = "HKLM:\SYSTEM\CurrentControlSet", "HKLM:\SYSTEM\DriverDatabase\DriverPackages"
    $RegistryLists = @{}
    foreach ($Property in $PropertiesAndValues.Keys) {
        $RegistryLists[$Property] = Get-RegistryList -Paths $Paths -PropertyMatch $Property
    }

    Node localhost {
        function CreateRegistryBlock {
            param ([string]$Driver, [string]$ValueName, [string]$ValueData, [string]$ValueType)
            $safeName = ($ValueName + "_" + $Driver -replace '[^a-zA-Z0-9]', '_') -replace '_+', '_'
            Registry $safeName {
                Ensure    = "Present"
                Key       = $Driver
                ValueName = $ValueName
                ValueType = $ValueType
                ValueData = $ValueData
                Force     = $True
            }

            Write-Host "Configuring Registry: $Driver -> $ValueName = $ValueData"
        }

        foreach ($Property in $PropertiesAndValues.Keys) {
            $ValueName = $PropertiesAndValues[$Property].ValueName
            $ValueType = $PropertiesAndValues[$Property].ValueType
            $ValueData = $PropertiesAndValues[$Property].ValueData
            foreach ($Driver in $RegistryLists[$Property]) {
                CreateRegistryBlock -Driver $Driver -ValueName $ValueName -ValueData $ValueData -ValueType $ValueType
            }
        }
    }
}

PowerSettingsDSC

Set-Item -Path "WSMan:\localhost\MaxEnvelopeSizeKb" -Value "16384"
Start-DscConfiguration -Path .\PowerSettingsDSC -Wait -Verbose -Force

Write-Host "nDSC Configuration complete. All matching registry values were set."
Pause