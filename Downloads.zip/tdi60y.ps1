Configuration FullScreenOptimizationConfig {
    param (
        [Parameter(Mandatory)]
        [string]$MySID,

        [Parameter()]
        [bool]$FullScreenOptimizations = $true,

        [Parameter()]
        [bool]$VariableRefreshRate = $true,

        [Parameter()]
        [bool]$AutoHDR = $false
    )

    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'

    Node localhost {

        $BadGameConfigStores = @(
            "HKEY_USERS\$MySID\Software\Classes\System\GameConfigStore",
            "HKEY_USERS\.DEFAULT\System\GameConfigStore",
            "HKEY_USERS\S-1-5-19\System\GameConfigStore",
            "HKEY_USERS\S-1-5-20\System\GameConfigStore",
            "HKEY_USERS\Software\Classes\System\GameConfigStore"
        )

        foreach ($path in $BadGameConfigStores) {
            Registry ("RemoveBadGameConfigStore_" + ($path -replace '\\', '_')) {
                Ensure = "Absent"
                Key = $path
                ValueName = ""
                Force = $true
            }
        }


        $Settings = @{
            "AllowGameDVR_Policy"                   = @{ Key = "HKLM:\SOFTWARE\Microsoft\PolicyManager\default\ApplicationManagement\AllowGameDVR"; ValueName = "value"; Type = "DWord"; Data = 0 }
            "AllowGameDVR"                          = @{ Key = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR"; ValueName = "AllowGameDVR"; Type = "DWord"; Data = 0 }
            "AppCaptureEnabled"                     = @{ Key = "Registry::HKEY_USERS\$MySID\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR"; ValueName = "AppCaptureEnabled"; Type = "DWord"; Data = 0 }
            "AudioCaptureEnabled"                   = @{ Key = "Registry::HKEY_USERS\$MySID\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR"; ValueName = "AudioCaptureEnabled"; Type = "DWord"; Data = 0 }
            "CursorCaptureEnabled"                  = @{ Key = "Registry::HKEY_USERS\$MySID\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR"; ValueName = "CursorCaptureEnabled"; Type = "DWord"; Data = 0 }
            "HistoricalCaptureEnabled"              = @{ Key = "Registry::HKEY_USERS\$MySID\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR"; ValueName = "HistoricalCaptureEnabled"; Type = "DWord"; Data = 0 }
            "MicrophoneCaptureEnabled"              = @{ Key = "Registry::HKEY_USERS\$MySID\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR"; ValueName = "MicrophoneCaptureEnabled"; Type = "DWord"; Data = 0 }
            "AllowAutoGameMode"                     = @{ Key = "Registry::HKEY_USERS\$MySID\Software\Microsoft\GameBar"; ValueName = "AllowAutoGameMode"; Type = "DWord"; Data = [int]$FullScreenOptimizations }
            "AutoGameModeEnabled"                   = @{ Key = "Registry::HKEY_USERS\$MySID\Software\Microsoft\GameBar"; ValueName = "AutoGameModeEnabled"; Type = "DWord"; Data = [int]$FullScreenOptimizations }
            "GamepadDoublePressIntervalMs"          = @{ Key = "Registry::HKEY_USERS\$MySID\Software\Microsoft\GameBar"; ValueName = "GamepadDoublePressIntervalMs"; Type = "DWord"; Data = 0 }
            "UseNexusForGameBarEnabled"             = @{ Key = "Registry::HKEY_USERS\$MySID\Software\Microsoft\GameBar"; ValueName = "UseNexusForGameBarEnabled"; Type = "DWord"; Data = 0 }
            "DirectXUserGlobalSettings"             = @{ Key = "Registry::HKEY_USERS\$MySID\Software\Microsoft\DirectX\UserGpuPreferences"; ValueName = "DirectXUserGlobalSettings"; Type = "String"; Data = "AutoHDREnable=$([int]$AutoHDR);SwapEffectUpgradeEnable=$([int]$FullScreenOptimizations);VRROptimizeEnable=$([int]$VariableRefreshRate);" }
            "GameDVR_DXGIHonorFSEWindowsCompatible" = @{ Key = "Registry::HKEY_USERS\$MySID\System\GameConfigStore"; ValueName = "GameDVR_DXGIHonorFSEWindowsCompatible"; Type = "DWord"; Data = if ($FullScreenOptimizations) { 0 } else { 1 } }
            "GameDVR_EFSEFeatureFlags"              = @{ Key = "Registry::HKEY_USERS\$MySID\System\GameConfigStore"; ValueName = "GameDVR_EFSEFeatureFlags"; Type = "DWord"; Data = 0 }
            "GameDVR_Enabled"                       = @{ Key = "Registry::HKEY_USERS\$MySID\System\GameConfigStore"; ValueName = "GameDVR_Enabled"; Type = "DWord"; Data = 0 }
            "GameDVR_FSEBehaviorMode"               = @{ Key = "Registry::HKEY_USERS\$MySID\System\GameConfigStore"; ValueName = "GameDVR_FSEBehaviorMode"; Type = "DWord"; Data = if ($FullScreenOptimizations) { 0 } else { 2 } }
            "GameDVR_HonorUserFSEBehaviorMode"      = @{ Key = "Registry::HKEY_USERS\$MySID\System\GameConfigStore"; ValueName = "GameDVR_HonorUserFSEBehaviorMode"; Type = "DWord"; Data = if ($FullScreenOptimizations) { 0 } else { 1 } }
            "SwapEffectUpgradeCache"                = @{ Key = "Registry::HKEY_USERS\$MySID\Software\Microsoft\DirectX\GraphicsSettings"; ValueName = "SwapEffectUpgradeCache"; Type = "DWord"; Data = [int]$FullScreenOptimizations }
        }

        foreach ($settingName in $Settings.Keys) {
            $s = $Settings[$settingName]
            Registry $settingName {
                Ensure = "Present"
                Key = $s.Key
                ValueName = $s.ValueName
                ValueType = $s.Type
                ValueData = "$($s.Data)"
                Force = $true
            }
        }


        if (-not $FullScreenOptimizations) {
            Registry GameDVR_DSEBehavior {
                Ensure = "Present"
                Key = "Registry::HKEY_USERS\$MySID\System\GameConfigStore"
                ValueName = "GameDVR_DSEBehavior"
                ValueType = "DWord"
                ValueData = "2"
                Force = $true
            }
            Registry GameDVR_FSEBehavior {
                Ensure = "Present"
                Key = "HKLM:\SOFTWARE\Microsoft\Windows\Dwm"
                ValueName = "OverlayTestMode"
                ValueType = "DWord"
                ValueData = "5"
                Force = $true
            }
            Registry DisableOverlays {
                Ensure = "Present"
                Key = "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers"
                ValueName = "DisableOverlays"
                ValueType = "DWord"
                ValueData = "1"
                Force = $true
            }
        } else {
            Registry GameDVR_DSEBehavior {
                Ensure = "Absent"
                Key = "Registry::HKEY_USERS\$MySID\System\GameConfigStore"
                ValueName = "GameDVR_DSEBehavior"
                Force = $true
            }
            Registry GameDVR_FSEBehavior {
                Ensure = "Absent"
                Key = "Registry::HKEY_USERS\$MySID\System\GameConfigStore"
                ValueName = "GameDVR_FSEBehavior"
                Force = $true
            }
            Registry OverlayTestMode {
                Ensure = "Absent"
                Key = "HKLM:\SOFTWARE\Microsoft\Windows\Dwm"
                ValueName = "OverlayTestMode"
                Force = $true
            }
            Registry DisableOverlays {
                Ensure = "Absent"
                Key = "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers"
                ValueName = "DisableOverlays"
                Force = $true
            }
        }
   }
}

Write-Host "Compiling FullScreenOptimizationConfig configuration..."

FullScreenOptimizationConfig -MySID "S-1-5-21-..." -FullScreenOptimizations $false -VariableRefreshRate $true -AutoHDR $false

Write-Host "Configuration compiled successfully."
Write-Host "Starting DSC configuration application..."

Start-DscConfiguration -Path .\FullScreenOptimizationConfig -Wait -Verbose -Force

Write-Host "DSC configuration applied successfully."
pause