Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

function Set-Ownership {
    param ([string]$Path)
    if (Test-Path $Path) {
        $isDir = (Get-Item $Path) -is [System.IO.DirectoryInfo]
        if ($isDir) {
            takeown /f $Path /r /d y | Out-Null
            icacls $Path /grant 'SYSTEM:F' /t /c | Out-Null
            icacls $Path /grant 'Administrators:F' /t /c | Out-Null
        } else {
            takeown /f $Path /d y | Out-Null
            icacls $Path /grant 'SYSTEM:F' /c | Out-Null
            icacls $Path /grant 'Administrators:F' /c | Out-Null
        }
    }
}

$TargetPaths = @(
    "C:\Program Files (x86)\Microsoft\EdgeUpdate",
    "C:\Windows\System32\smartscreen.exe",
    "C:\Program Files\Internet Explorer",
    "C:\Program Files\Microsoft Update Health Tools",
    "C:\Program Files\Windows Defender",
    "C:\Program Files\Windows Defender Advanced Threat Protection",
    "C:\Program Files (x86)\Microsoft",
    "C:\Program Files (x86)\Internet Explorer",
    "C:\Program Files (x86)\Windows Mail",
    "C:\Windows\SystemApps\microsoft.windows.narratorquickstart_8wekyb3d8bbwe",
    "C:\Windows\SystemApps\ParentalControls_cw5n1h2txyewy",
    "C:\Windows\SystemApps\NcsiUwpApp_8wekyb3d8bbwe",
    "C:\Windows\SystemApps\MicrosoftWindows.UndockedDevKit_cw5n1h2txyewy",
    "C:\Windows\SystemApps\Microsoft.LockApp_cw5n1h2txyewy",
    "C:\Windows\SystemApps\Microsoft.Windows.AppResolverUX_cw5n1h2txyewy",
    "C:\Windows\SystemApps\Microsoft.MicrosoftEdgeDevToolsClient_8wekyb3d8bbwe",
    "C:\Windows\SystemApps\Microsoft.Windows.ContentDeliveryManager_cw5n1h2txyewy",
    "C:\Windows\SystemApps\Microsoft.Windows.AppRep.ChxApp_cw5n1h2txyewy",
    "$env:LOCALAPPDATA\Microsoft\OneDrive"
)

$TargetServices = @("edgeupdate", "edgeupdatem")
$TargetProcesses = @("epicwebhelper","steamwebhelper","robloxcrashhandler","OneDrive","msedge","smartscreen")

foreach ($Path in $TargetPaths) {
    Set-Ownership -Path $Path
}

Configuration CleanupConfig {
    param([string[]]$Paths, [string[]]$Services, [string[]]$Processes)
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost {
        
        foreach ($Svc in $Services) {
            Service "Stop_$Svc" {
                Name = $Svc
                State = "Stopped"
                StartupType = "Disabled"
            }
        }

        Script StopUselessProcesses {
            GetScript = { return @{ 'Result' = 'Monitor' } }
            TestScript = { 
                foreach($p in $using:Processes) { if(Get-Process -Name $p -ErrorAction SilentlyContinue) { return $false } }
                return $true
            }
            SetScript = {
                foreach ($p in $using:Processes) {
                    Get-Process -Name $p -ErrorAction SilentlyContinue | Stop-Process -Force
                }
            }
        }

        $Count = 0
        foreach ($P in $Paths) {
            $Count++
            $Type = if ($P -like "*.*") { "File" } else { "Directory" }
            File "Cleanup_$Count" {
                Ensure = "Absent"
                Type = $Type
                DestinationPath = $P
                Force = $true
                Recurse = $true
            }
        }
    }
}

Write-Host '=========================================' -ForegroundColor Cyan
Write-Host ' Deblatoating Windows With DSC           ' -ForegroundColor Cyan
Write-Host '=========================================' -ForegroundColor Cyan

$ConfigPath = Join-Path -Path $env:Temp -ChildPath 'CleanupConfig'
if (Test-Path $ConfigPath) { Remove-Item -Path $ConfigPath -Recurse -Force }

CleanupConfig -Paths $TargetPaths -Services $TargetServices -Processes $TargetProcesses -OutputPath $ConfigPath | Out-Null
Start-DscConfiguration -Path $ConfigPath -Wait -Verbose -Force

cls

Write-Host '=========================================' -ForegroundColor Yellow
Write-Host ' Stopping USELESS Windows Services       ' -ForegroundColor Yellow
Write-Host '=========================================' -ForegroundColor Yellow
foreach ($SvcName in $TargetServices) {
    $service = Get-Service -Name $SvcName -ErrorAction SilentlyContinue
    if ($null -eq $service -or $service.StartType -eq 'Disabled') {
        Write-Host ("[ OK ] {0,-40} - Disabled" -f $SvcName) -ForegroundColor Green
    } else {
        Write-Host ("[FAIL] {0,-40} - still running" -f $SvcName) -ForegroundColor Red
    }
}

Write-Host "`n"
foreach ($ProcName in $TargetProcesses) {
    if (Get-Process -Name $ProcName -ErrorAction SilentlyContinue) {
        Write-Host ("[FAIL] {0,-40} - still active" -f $ProcName) -ForegroundColor Red
    } else {
        Write-Host ("[ OK ] {0,-40} - terminated" -f $ProcName) -ForegroundColor Green
    }
}
Start-Sleep -Seconds 2

Write-Host "`n"
Write-Host '=========================================' -ForegroundColor Yellow
Write-Host ' Cheking files . . . .                   ' -ForegroundColor Yellow
Write-Host '=========================================' -ForegroundColor Yellow
foreach ($Path in $TargetPaths) {
    $Name = Split-Path -Path $Path -Leaf
    if (Test-Path $Path) {
        Write-Host ("[FAIL] {0,-40} - still present" -f $Name) -ForegroundColor Red
    } else {
        Write-Host ("[ OK ] {0,-40} - removed" -f $Name) -ForegroundColor Green
    }
}

Write-Host "`n"
Write-Host ''
Write-Host '=========================================' -ForegroundColor Yellow
Write-Host '    Removing Edge . . . .                ' -ForegroundColor Yellow
Write-Host '=========================================' -ForegroundColor Yellow
Write-Host ''

for ($i = 3; $i -ge 1; $i--) {
    Write-Host " Edge removal begins in $i..." -ForegroundColor Magenta
    Start-Sleep -Seconds 1
}

$EdgeRemoverPath = Join-Path -Path $env:TEMP -ChildPath 'DEBLOAT\EDG.bat'
if (Test-Path $EdgeRemoverPath) {
    Start-Process -FilePath $EdgeRemoverPath -Verb RunAs -Wait
    Write-Host "`n"
    Write-Host '=========================================' -ForegroundColor Yellow
    Write-Host '    Edge REMOVED . . . .                ' -ForegroundColor Yellow
    Write-Host '=========================================' -ForegroundColor Yellow
} else {
    Write-Host "Edge removal script not found at $EdgeRemoverPath" -ForegroundColor Red
}
    Start-Sleep -Seconds 2

Write-Host "`n"
Write-Host "===============================" -ForegroundColor Cyan
Write-Host " Removing Built-in Windows Apps" -ForegroundColor Cyan
Write-Host "===============================" -ForegroundColor Cyan
Write-Host ""

$appPatterns = @(
    "*OfficeHub*", "*Microsoft.YourPhone*", "*Microsoft.PowerAutomate*", "*MicrosoftSolitaireCollection*",
    "*MicrosoftStickyNotes*", "*MicrosoftTips*", "*MicrosoftToDo*", "*MicrosoftWeather*",
    "*Microsoft.MobileEnrollment*", "*Microsoft.MicrosoftEdge.Stable*", "*MicrosoftEdge*",
    "*Microsoft.Outlook*", "*Microsoft.OneDrive*", "*7EE7776C.LinkedInforWindows*",
    "*Mirkat.Mirkat*", "*RealtekSemiconductorCorp.RealtekAudioControl*", "*Microsoft.MixedReality.Portal*",
    "*Microsoft.Wallet*", "*Microsoft.3DBuilder*", "*Duolingo-LearnLanguagesforFree*",
    "*PandoraMediaInc*", "*CandyCrush*", "*BubbleWitch3Saga*", "*Wunderlist*", "*Flipboard*",
    "*Twitter*", "*Facebook*", "*Royal Revolt*", "*Sway*", "*Speed Test*", "*Dolby*",
    "*Microsoft.ZuneMusic*", "*EclipseManager*", "*ActiproSoftwareLLC*",
    "*AdobeSystemsIncorporated.AdobePhotoshopExpress*", "*Microsoft.Office.Lens*",
    "*Microsoft.Office.Sway*", "*OneConnect*", "*Microsoft.RemoteDesktop*", "*Microsoft.Office.Todo*",
    "*Microsoft.Whiteboard*", "*Microsoft.People*", "*Microsoft.Todos*",
    "*Microsoft.PowerAutomateDesktop*", "*Microsoft.SkypeApp*", "*Microsoft.WindowsAlarms*",
    "*Microsoft.WindowsFeedbackHub*", "*Microsoft.WindowsMaps*", "*Microsoft.WindowsSoundRecorder*",
    "*Microsoft.Cortana*", "*Microsoft.BingNews*", "*Microsoft.BingWeather*", "*Microsoft.Getstarted*",
    "*Microsoft.Messaging*", "*NetworkSpeedTest*", "*Microsoft.ParentalControls*", "*OutlookForWindows*",
    "*Microsoft.QuickAssist*", "*Microsoft.ScreenSketch*", "*Disney*", "*Spotify*",
    "*PeopleExperienceHost*", "*Microsoft.NarratorQuickStart*", "*Microsoft.GetHelp*",
    "*Microsoft.Microsoft3DViewer*", "*Microsoft.Office.OneNote*", "*Clipchamp*",
    "*Microsoft.WindowsTerminal*", "*MicrosoftTeams*", "*Windows.DevHome*", "*Windows.CrossDevice*",
    "*Windows.SecHealthUI*", "*Microsoft.ZuneVideo*", "*WebpImageExtension*", "*WebMediaExtensions*",
    "*Microsoft.Windows.ContentDeliveryManager*", "*RawImageExtension*", "*Windows.UndockedDevKit*"
)

Write-Host "Scanning system for matching packages..." -ForegroundColor Gray
$installedApps = Get-AppxPackage -AllUsers
$provisionedApps = Get-AppxProvisionedPackage -Online

foreach ($pattern in $appPatterns) {
    $cleanName = $pattern.Replace("*", "")
    
    # Check if the app is currently installed
    $match = $installedApps | Where-Object { $_.Name -like $pattern -or $_.PackageFullName -like $pattern }
    
    if ($null -ne $match) {
        foreach ($item in $match) {
            Write-Host "[ FOUND ] Removing: $($item.Name)" -ForegroundColor Yellow
            $item | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue
        }
    }

    $provMatch = $provisionedApps | Where-Object { $_.DisplayName -like $pattern -or $_.PackageName -like $pattern }
    if ($null -ne $provMatch) {
        foreach ($provItem in $provMatch) {
            Remove-AppxProvisionedPackage -Online -PackageName $provItem.PackageName -ErrorAction SilentlyContinue
        }
    }
}

Write-Host "`n"
Write-Host '=========================================' -ForegroundColor Yellow
Write-Host ' APPX Removed                           ' -ForegroundColor Yellow
Write-Host '=========================================' -ForegroundColor Yellow

$finalCheckList = Get-AppxPackage -AllUsers

foreach ($pattern in $appPatterns) {
    $displayName = $pattern.Replace("*","")
    $isStillThere = $finalCheckList | Where-Object { $_.Name -like $pattern -or $_.PackageFullName -like $pattern }
    
    if ($null -ne $isStillThere) {
        Write-Host ("[FAIL] {0,-40} - still present" -f $displayName) -ForegroundColor Red
    } else {
        # Optional: only show OK for things we actually tried to remove to keep logs clean
        Write-Host ("[ OK ] {0,-40} - gone/not found" -f $displayName) -ForegroundColor Green
    }
}

Write-Host "`n"
Write-Host "===================================" -ForegroundColor Green
Write-Host " Windows Debloating With DSC Done." -ForegroundColor Green
Write-Host "===================================" -ForegroundColor Green
Write-Host "`n"
    Write-Host " Closing Script in $i..." -ForegroundColor Magenta
    Start-Sleep -Seconds 1